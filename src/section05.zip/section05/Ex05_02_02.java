package section05;

public class Ex05_02_02 {
    public static void main(String[] args) {
        for(int i = 0, j=5; i< 5; i++, j--){
            System.out.printf("i = %d, j = %d\n", i , j);
        }
    }
}
