package section05;

public class Ex05_03 {
    public static void main(String[] args) {
        for (int i = 2; i <= 9; i++) {
            // System.out.println(i + "단");
            for (int j = 1; j <= 9; j++) {
                System.out.printf("%d X %d = %d\t", i, j, i * j);
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 1; i <= 9; i++) {
            // System.out.println(i + "단");
            for (int j = 2; j <= 9; j++) {
                System.out.printf("%d X %d = %d\t", j, i, i * j);
                // System.out.println();
            }
            System.out.println();
        }
        // 특수문자 사용 단축키 win + .
        // System.out.printf("%d × %d = %d",i,1,i*1);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,2,i*2);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,3,i*3);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,4,i*4);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,5,i*5);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,6,i*6);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,7,i*7);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,8,i*9);
        // System.out.println();
        // System.out.printf("%d × %d = %d",i,9,i*9);
        // System.out.printf("%d단: %d × %d =", i);
        // System.out.println();
    }
}
