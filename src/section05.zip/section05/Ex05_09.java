package section05;

public class Ex05_09 {
    public static void main(String[] args) {
        int i=0;
        while(true){
            
            if (i == 6) {
                break;
            }
            System.out.println(i);
            i++;
        }
    }
}
