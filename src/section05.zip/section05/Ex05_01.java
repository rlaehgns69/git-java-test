package section05;

public class Ex05_01 {
    public static void main(String[] args) {
        // 반복문 사용하지 않은 경우
        // System.out.println(1);
        // System.out.println(2);
        // System.out.println(3);
        // System.out.println(4);
        // System.out.println(5);
        // System.out.println(6);
        // System.out.println(7);
        // System.out.println(8);
        // System.out.println(9);
        // System.out.println(10);
        for(int i=1; i<=1000; i++){
            System.out.println(i);
        }
    }   
}
// ctrl + , settings